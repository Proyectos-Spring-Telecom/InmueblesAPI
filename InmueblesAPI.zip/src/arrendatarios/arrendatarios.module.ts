import { Module } from "@nestjs/common";
import { TypeOrmModule } from "@nestjs/typeorm";
import { Arrendatarios } from "src/entities/Arrendatarios";
import { ArchivosArrendatarios } from "src/entities/ArchivosArrendatarios";
import { ContratoArrendatarios } from "src/entities/ContratoArrendatarios";
import { ContratoLocales } from "src/entities/ContratoLocales";
import { ServiciosArrendatarios } from "src/entities/ServiciosArrendatarios";
import { SociosArrendatarios } from "src/entities/SociosArrendatarios";
import { HistoricoPagosRenta } from "src/entities/HistoricoPagosRenta";
import { LocalesZonaInmueble } from "src/entities/LocalesZonaInmueble";
import { PagosArrendatarios } from "src/entities/PagosArrendatarios";
import { RentaActual } from "src/entities/RentaActual";
import { ZonasInmuebles } from "src/entities/ZonasInmuebles";
import { S3Module } from "src/s3/s3.module";
import { ArrendatariosController } from "./arrendatarios.controller";
import { ArrendatariosDashboardService } from "./arrendatarios-dashboard.service";
import { ArrendatariosService } from "./arrendatarios.service";

@Module({
  imports: [
    TypeOrmModule.forFeature([
      Arrendatarios,
      ContratoArrendatarios,
      ContratoLocales,
      ServiciosArrendatarios,
      ArchivosArrendatarios,
      SociosArrendatarios,
      ZonasInmuebles,
      LocalesZonaInmueble,
      HistoricoPagosRenta,
      RentaActual,
      PagosArrendatarios,
    ]),
    S3Module,
  ],
  controllers: [ArrendatariosController],
  providers: [ArrendatariosService, ArrendatariosDashboardService],
  exports: [ArrendatariosService],
})
export class ArrendatariosModule {}
